#ifndef AUX
#define AUX

#include "tokens.hpp"
#include "output.hpp"
#include <iostream>
#include <string>



bool printable(const char c);
std::string handleString(const char* val);

#endif